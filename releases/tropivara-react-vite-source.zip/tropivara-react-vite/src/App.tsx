import { Component, type ReactNode } from "react";
import { BrowserRouter, Route as RRRoute, Routes } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Link, RouteElement, ScrollManager, applyHead } from "@/lib/router-compat";
import { LanguageProvider, useI18n } from "@/i18n/LanguageProvider";
import { SiteLayout } from "@/components/site/Layout";
import { Route as Home } from "@/pages/index";
import { Route as About } from "@/pages/about";
import { Route as Products } from "@/pages/products.index";
import { Route as ProductDetail } from "@/pages/products.$slug";
import { Route as Origins } from "@/pages/origins";
import { Route as Quality } from "@/pages/quality";
import { Route as Contact } from "@/pages/contact";

const pages = [Home, About, Products, ProductDetail, Origins, Quality, Contact];
const toRR = (p: string) => p.replace(/\$(\w+)/g, ":$1");
const queryClient = new QueryClient();

function NotFoundComponent() {
  const { t } = useI18n();
  return (
    <div className="container-page flex min-h-[60vh] flex-col items-start justify-center py-24">
      <p className="eyebrow">404</p>
      <h1 className="mt-3 text-5xl text-forest-deep">{t.notFound.title}</h1>
      <p className="mt-4 text-muted-foreground">{t.notFound.body}</p>
      <Link to="/" className="btn btn-primary mt-8">{t.notFound.home}</Link>
    </div>
  );
}

class ErrorBoundary extends Component<{ children: ReactNode }, { error: unknown }> {
  override state = { error: null as unknown };
  static getDerivedStateFromError(error: unknown) {
    return { error };
  }
  override componentDidCatch(error: unknown) {
    console.error(error);
  }
  override render() {
    if (!this.state.error) return this.props.children;
    return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">This page didn't load</h1>
        <p className="mt-2 text-sm text-muted-foreground">Something went wrong on our end. You can try refreshing or head back home.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button onClick={() => this.setState({ error: null })} className="btn btn-primary">Try again</button>
          <a href="/" className="btn btn-outline">Go home</a>
        </div>
      </div>
    </div>
  );
  }
}

function NotFoundPage() {
  applyHead({ meta: [{ title: "Page not found — Tropivara" }, { name: "robots", content: "noindex" }] });
  return <NotFoundComponent />;
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <BrowserRouter>
          <ScrollManager />
          <ErrorBoundary>
            <SiteLayout>
              <Routes>
                {pages.map((p) => (
                  <RRRoute key={p.path} path={toRR(p.path)} element={<RouteElement def={p} NotFound={NotFoundComponent} />} />
                ))}
                <RRRoute path="*" element={<NotFoundPage />} />
              </Routes>
            </SiteLayout>
          </ErrorBoundary>
        </BrowserRouter>
      </LanguageProvider>
    </QueryClientProvider>
  );
}
