// Small adapter so page files keep their original shape while running on React Router.
import { createContext, useContext, useEffect, type ComponentType, type ReactNode } from "react";
import { NavLink, Link as RRLink, useLocation, useParams, useSearchParams } from "react-router-dom";

type Tag = Record<string, string | undefined>;
export type HeadResult = { meta?: Tag[]; links?: Tag[] };

class NotFoundError extends Error {
  isNotFound = true;
}
export const notFound = () => new NotFoundError("Not found");
export const isNotFound = (e: unknown) => !!(e && typeof e === "object" && "isNotFound" in e);

export type RouteDef = {
  path: string;
  component: ComponentType;
  loader?: (a: { params: any }) => unknown;
  head?: (a: { loaderData?: any; params: Record<string, string> }) => HeadResult;
  validateSearch?: (s: Record<string, unknown>) => any;
  useLoaderData: () => any;
  useSearch: () => any;
};

const LoaderCtx = createContext<unknown>(undefined);

export function createFileRoute(path: string) {
  return (opts: Omit<RouteDef, "path" | "useLoaderData" | "useSearch">): RouteDef => {
    const def: RouteDef = {
      ...opts,
      path,
      useLoaderData: () => useContext(LoaderCtx),
      useSearch: () => {
        const [sp] = useSearchParams();
        const raw = Object.fromEntries(sp.entries());
        return def.validateSearch ? def.validateSearch(raw) : raw;
      },
    };
    return def;
  };
}

const MANAGED = "data-rr-head";
export function applyHead(head: HeadResult) {
  document.head.querySelectorAll(`[${MANAGED}]`).forEach((n) => n.remove());
  for (const m of head.meta ?? []) {
    if (m["title"] !== undefined) {
      document.title = m["title"]!;
      continue;
    }
    const key = m["name"] ? "name" : m["property"] ? "property" : null;
    if (key) document.head.querySelectorAll(`meta[${key}="${m[key]}"]`).forEach((n) => n.remove());
    const el = document.createElement("meta");
    for (const [k, v] of Object.entries(m)) if (v !== undefined) el.setAttribute(k === "charSet" ? "charset" : k, v);
    el.setAttribute(MANAGED, "");
    document.head.appendChild(el);
  }
  for (const l of head.links ?? []) {
    const el = document.createElement("link");
    for (const [k, v] of Object.entries(l)) if (v !== undefined) el.setAttribute(k === "crossOrigin" ? "crossorigin" : k, v);
    el.setAttribute(MANAGED, "");
    document.head.appendChild(el);
  }
}

export function RouteElement({ def, NotFound }: { def: RouteDef; NotFound: ComponentType }) {
  const params = useParams() as Record<string, string>;
  let data: unknown;
  let missing = false;
  try {
    data = def.loader?.({ params });
  } catch (e) {
    if (isNotFound(e)) missing = true;
    else throw e;
  }
  useEffect(() => {
    if (!missing && def.head) applyHead(def.head({ loaderData: data, params }));
  });
  if (missing) return <NotFound />;
  const C = def.component;
  return (
    <LoaderCtx.Provider value={data}>
      <C />
    </LoaderCtx.Provider>
  );
}

type LinkProps = {
  to: string;
  params?: Record<string, string>;
  search?: Record<string, string | undefined>;
  hash?: string;
  className?: string;
  activeProps?: { className?: string };
  activeOptions?: { exact?: boolean };
  children?: ReactNode;
  onClick?: () => void;
  "aria-label"?: string;
};

export function Link({ to, params, search, hash, className, activeProps, activeOptions, children, ...rest }: LinkProps) {
  let path = to;
  for (const [k, v] of Object.entries(params ?? {})) path = path.replace(`$${k}`, encodeURIComponent(v));
  const qs = new URLSearchParams(Object.entries(search ?? {}).filter(([, v]) => v !== undefined) as [string, string][]).toString();
  const href = path + (qs ? `?${qs}` : "") + (hash ? `#${hash}` : "");
  if (activeProps) {
    return (
      <NavLink to={href} end={activeOptions?.exact ?? false} className={({ isActive }) => [className, isActive ? activeProps.className : ""].filter(Boolean).join(" ")} {...rest}>
        {children}
      </NavLink>
    );
  }
  return <RRLink to={href} className={className} {...rest}>{children}</RRLink>;
}

/** Scroll to top on navigation, or to the #hash target when present. */
export function ScrollManager() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const el = document.getElementById(decodeURIComponent(hash.slice(1)));
      if (el) return el.scrollIntoView();
    }
    window.scrollTo(0, 0);
  }, [pathname, hash]);
  return null;
}
