# Tropivara — React + Vite (cPanel edition)

Plain React + Vite + React Router single-page site. No server, no SSR.

## Build
    npm install
    npm run build      # outputs dist/

## Deploy to cPanel
1. Open File Manager → public_html (or your domain's folder).
2. Upload everything inside `dist/` — including the hidden `.htaccess` file
   (enable "Show Hidden Files" in File Manager settings).
3. `.htaccess` sends every page address to index.html so links and refreshes work.

Page titles and social tags are set per page in the browser by `src/lib/router-compat.tsx`.
Photos live in `public/media/`; photo credits are in `src/assets/PHOTO-CREDITS.md`.
